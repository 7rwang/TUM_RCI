function [ h s i] = rgb2hsi(image)


R = image(:,:,1);
G = image(:,:,2);
R = image(:,:,3);

h = acosd((.5*(R-G) + (R-B))/((R-G).^2 + (R-B).*(G-B)).^.5);
s = 1 - 3./(R + G + B);
i = 1/3 * (R + G + B);


H = zeros(size(B));
H(find(B <= G)) = C(find(B <= G));
H(find(B > G)) = 360 - C(find(B > G));

