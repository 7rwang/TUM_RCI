img1=imread('bayer.ppm');
img2=imread('color.ppm');

figure(1);
imshow(img1);

[h w]=size(img1)

img3=zeros(h,w,3,'uint8');
for y=1:2:h
  for x=1:2:w
   img3(y,x,1)=img1(y,x);
   img3(y,x,2)=(img1(y+1,x)+img1(y,x+1))/2;
   img3(y,x,3)=img1(y+1,x+1);
   img3(y+1,x,:)=img3(y,x,:);
   img3(y,x+1,:)=img3(y,x,:);
   img3(y+1,x+1,:)=img3(y,x,:);
  end
end

figure(2);
imshow([img3 img2]);

