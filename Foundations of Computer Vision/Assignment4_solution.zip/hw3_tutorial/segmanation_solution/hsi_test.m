I=imread('california.jpg');
[h s i]=rgb2hsv(I);
figure(1);
imshow(I);
figure(2);
imshow([i h s]);
imshow(i(s>0.2 & h<0.1))
